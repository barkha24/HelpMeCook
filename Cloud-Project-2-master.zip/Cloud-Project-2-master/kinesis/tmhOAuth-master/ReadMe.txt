Run script.html 
(keep tmhOAuth.php ,tweets_json.php and script.html in same folder)